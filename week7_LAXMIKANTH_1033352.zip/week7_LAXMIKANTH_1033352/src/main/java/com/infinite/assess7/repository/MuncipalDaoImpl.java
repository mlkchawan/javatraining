package com.infinite.assess7.repository;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.assess7.model.Muncipal;


@Repository
public class MuncipalDaoImpl implements ImunicipalDao {

	@Autowired
	private SessionFactory SessionFactory;

	public void setSessionFactory(Session sessionFactory) {
		this.SessionFactory = SessionFactory;
	}

	
	public List<Muncipal> getAllComplains() {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		List<Muncipal> ls = session.createQuery("from municipal").list();
		return ls;
	}

	
	public Muncipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		Muncipal Muncipal = (Muncipal) session.get(Muncipal.class, id);
		return Muncipal;
	}

	
	public Muncipal addMunicipal(Muncipal Muncipal) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		session.save(Muncipal);
		return null;
	}

	public void updateMunicipal(Muncipal municipal) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		Hibernate.initialize(municipal);
		session.update(municipal);
	}

	
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		Muncipal m = (Muncipal) session.load(Muncipal.class, new Integer(id));
		if (null != m) {
			session.delete(m);
		}
	
	}


	public List<Muncipal> getAllComplaints() {
		// TODO Auto-generated method stub
		return null;
	}
}