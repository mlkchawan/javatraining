package com.infinite.assess7.repository;

import java.util.List;

import com.infinite.assess7.model.Muncipal;

public interface ImunicipalDao {

	public List<Muncipal> getAllComplaints();  // for getting all complaints

	public Muncipal getMunicipal(int id);             

	public Muncipal addMunicipal(Muncipal municipal); // add details 

	public void updateMunicipal(Muncipal municipal);   // updating the record
 
	public void deleteMunicipal(int id);   // deleting the records
}


