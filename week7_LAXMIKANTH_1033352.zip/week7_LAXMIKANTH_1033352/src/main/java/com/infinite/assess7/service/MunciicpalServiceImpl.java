package com.infinite.assess7.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.assess7.model.Muncipal;
import com.infinite.assess7.model.MuncipalDetails;
import com.infinite.assess7.repository.MuncipalDaoImpl;

@Service
public class MunciicpalServiceImpl implements ImunicipalService {

	@Autowired
	MuncipalDaoImpl MunicipalDAOImpl;

	@Transactional
	public List<Muncipal> getAllComplains() {
		// TODO Auto-generated method stub

		return MunicipalDAOImpl.getAllComplains();
	}

	@Transactional
	public Muncipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.getMunicipal(id);
	}

	@Transactional
	public Muncipal addMunicipal(Muncipal municipal) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.addMunicipal(municipal);
	}

	@Transactional
	public void updateMunicipal(Muncipal municipalinfo) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.updateMunicipal(municipalinfo);
	}

	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.deleteMunicipal(id);
	}

}