package com.infinite.assess7.controller;

//@ laxmikanthm

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.assess7.model.Muncipal;
import com.infinite.assess7.model.MuncipalDetails;
import com.infinite.assess7.service.MunciicpalServiceImpl;

@Controller
public class MainController {
	@Autowired
	MunciicpalServiceImpl cservice;
	/*
	 * @RequestMapping(value = "/", method = RequestMethod.GET, headers =
	 * "Accept=application/json") public String goToHomePage() { return
	 * "redirect:/getAllMunicipal"; }
	 * 
	 * @RequestMapping(value = "/getAllMunicipal", method = RequestMethod.GET)
	 * public String getAllCustomers(Model model) {
	 * model.addAttribute("Municipal", new Municipal());
	 * //model.addAttribute("listOfCustomers", cservice.getAllCustomers());
	 * return "municipaldetails"; }
	 */

	@RequestMapping(value = "/", method = RequestMethod.GET, headers = "Accept=application/json")
	public String goToHomePage() {
		return "redirect:/getAllComplaints";
	}

	@RequestMapping(value = "/getAllComplaints", method = RequestMethod.GET, headers = "Accept=application/json")
	public String getAllComplains(Model m) {
		m.addAttribute("municipal", new MuncipalDetails());
		m.addAttribute("listOfComplains", cservice.getAllComplains());
		return "getAllComplaints";
	}

	@RequestMapping(value = "/addComplaints", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addComplains(@ModelAttribute("municipal") Muncipal municipal) {
		if (municipal.getId() == 0) {
			cservice.addMunicipal(municipal);
		} else {
			cservice.updateMunicipal(municipal);
			;
		}
		return "redirect:/getAllComplaints";
	}

	@RequestMapping(value = "/updateComplains/{id}")
	public String updateComplains(@PathVariable("id") int id, Model model) {
		model.addAttribute("municipal", this.cservice.getMunicipal(id));
		model.addAttribute("listOfComplains", this.cservice.getAllComplains());
		return "complaindetails";
	}
}
