package com.infinite.assess7.service;

import java.util.List;

import com.infinite.assess7.model.Muncipal;


public interface ImunicipalService {

	public List<Muncipal> getAllComplains();

	public Muncipal getMunicipal(int id);

	public Muncipal addMunicipal(Muncipal Muncipal);

	public void updateMunicipal(Muncipal Muncipal);

	public void deleteMunicipal(int id);

}