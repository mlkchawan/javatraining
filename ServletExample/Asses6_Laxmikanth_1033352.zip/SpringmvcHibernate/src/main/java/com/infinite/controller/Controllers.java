package com.infinite.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@laxmikanth

import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.infinite.daoimpl.Productmpl;
import com.infinite.pojo.Product;
import org.hibernate.SessionFactory;


@Controller
public class Controllers {
	
	
	@RequestMapping(value = "/coupon",method = RequestMethod.POST)
	public String traindetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		return "coupon";}
	
	private ApplicationContext con;    //initializing applicationcontext

	@RequestMapping(value = "/insert", method = RequestMethod.POST)       //request mapper to find child controller
	public String insert(@ModelAttribute("bean") Product e, Model m) {
		con = new ClassPathXmlApplicationContext("ApplicationContext.xml");    //creating obj for applicationcontext
		Productmpl obj = con.getBean("dao", Productmpl.class);
		obj.saveData(e);
		String Product = e.getProduct();  // gets the product name from the user
		String Price = e.getPrice();        // get the price from the user
		String Quantity = e.getQuantity();      // get the quantity name from user
		String subtotal = e.getSubtotal();      // get the subtotal from the user
		System.out.println("i");
		return "inserted";               // after successful insertion of data it redirect to inserted page 
	}

}