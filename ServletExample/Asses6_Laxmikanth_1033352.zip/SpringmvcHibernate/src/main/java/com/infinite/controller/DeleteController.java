package com.infinite.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class DeleteController {
	
	@RequestMapping(value = "/delete",method = RequestMethod.POST)
	public String traindetails(HttpServletRequest request, HttpServletResponse response) throws IOException {
		return "deleted";}
	
	/*private ApplicationContext con; //initializing applicationcontext

	 

	@RequestMapping(value = "/delete", method = RequestMethod.POST)  //request mapper to find child controller
	public String insert(@ModelAttribute("bean") Product e, Model m) {
		con = new ClassPathXmlApplicationContext("ApplicationContext.xml");  //creating object for applicationcontext
		Productmpl obj = con.getBean("dao", Productmpl.class);         //getting productimpl using bean id
		obj.deleteData(e); //delete data
		String Product = e.getProduct();
		int Price = e.getPrice();
		int Quantity = e.getQuantity();
		int Subtotal = e.getSubtotal();
		
		System.out.println("i");
		return "deleted";
	}*/

}
