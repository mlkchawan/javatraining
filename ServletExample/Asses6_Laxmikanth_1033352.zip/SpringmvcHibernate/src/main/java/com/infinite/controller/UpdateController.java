package com.infinite.controller;

public class UpdateController {

	/*private ApplicationContext con;  //initializing applicationcontext

		@RequestMapping(value="/update",method=RequestMethod.POST)  //request mapper to find child controller

		public String insert(@ModelAttribute("bean") Product e,Model m){  //model and getting attribute

			con=new ClassPathXmlApplicationContext("ApplicationContext.xml");  //creating object for applicationcontext

			Productmpl obj=con.getBean("dao",Productmpl.class); //getting productimpl using bean id

			obj.updateData(e);	//updating
			String ProductName=e.getProduct();
			int Price=e.getPrice();
			int Quantity=e.getQuantity();
			int SubTotal=e.getSubtotal();
			
			System.out.println("i");
			return "updated";	

		}*/

}
